package code;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Popup;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.List;

public class HomeController {

    @FXML private BorderPane mainPane;
    @FXML private Button btnNotification;
    @FXML private VBox notificationPane;
    @FXML private HBox gestiondescreances;

    private Popup popup = new Popup();
    private FXMLLoader currentLoader;
    private int userId;
    private String username;
    private String role;

    public void setUserData(int userId, String username, String role) {
        this.userId = userId;
        this.username = username;
        this.role = role;
        loadDashboard();
    }

    private void setCenterView(String fxmlPath, Runnable controllerInitializer) {
        try {
            currentLoader = new FXMLLoader(getClass().getResource(fxmlPath));
            Parent node = currentLoader.load();
            if (controllerInitializer != null) controllerInitializer.run();
            mainPane.setCenter(node);
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Erreur", "Échec de chargement de la vue: " + fxmlPath);
        }
    }

    private void setCenterView(String fxmlPath) {
        setCenterView(fxmlPath, null);
    }

    @FXML private void loadDashboard() {
        setCenterView("/views/Dashboard.fxml");
    }

    @FXML private void showClientsView() {
        setCenterView("/views/Clients.fxml", () -> {
            ClientController controller = (ClientController) currentLoader.getController();
            controller.setHomeController(this);
        });
    }

    @FXML private void showCreanceView() {
        setCenterView("/views/Creance.fxml");
    }

    public void showFacturesForClient(String clientId) {
        setCenterView("/views/Creance.fxml", () -> {
            CreanceController controller = (CreanceController) currentLoader.getController();
            controller.setClientFilter(clientId);
        });
    }

    @FXML private void showPaimentsView() {
        setCenterView("/views/Paiments.fxml");
    }

    @FXML private void handleLogout() {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/views/Login.fxml"));
            Stage stage = (Stage) mainPane.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Erreur", "Impossible de se déconnecter");
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    public void initialize() {
        btnNotification.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> toggleNotificationPopup());
        verifierAlertes();
    }

    private void verifierAlertes() {
        VBox alertsBox = new VBox();
        alertsBox.setSpacing(5);
        alertsBox.setStyle("-fx-background-color: white; -fx-border-color: gray; -fx-padding: 10;");

        List<Creance> creances = CreanceDao.getCreances();
        for (Creance c : creances) {
            if (c.getStatut().equals("en_retard")) {
                Label label = new Label("⚠️ Créance " + c.getId_Creance() + " en retard.");
                label.setStyle("-fx-text-fill: red; -fx-font-weight: bold;");
                alertsBox.getChildren().add(label);
            } else if (c.getMontantRestant() <= 0) {
                Label label = new Label("✅ Créance " + c.getId_Creance() + " payée.");
                label.setStyle("-fx-text-fill: green; -fx-font-weight: bold;");
                alertsBox.getChildren().add(label);
            }
        }

        popup.getContent().clear();
        popup.getContent().add(alertsBox);
        popup.setAutoHide(true);
    }

    private void toggleNotificationPopup() {
        if (popup.isShowing()) {
            popup.hide();
        } else {
            double x = btnNotification.localToScreen(btnNotification.getBoundsInLocal()).getMinX();
            double y = btnNotification.localToScreen(btnNotification.getBoundsInLocal()).getMaxY();
            popup.show(btnNotification, x, y);
        }
    }
}
