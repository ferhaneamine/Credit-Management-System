package code;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.layout.HBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.image.ImageView;

import java.io.IOException;
import java.util.List;

import static code.ClientDao.modifierClient;
import static code.ClientDao.supprimerClient;

public class ClientController {
    @FXML private TableView<Client> clientTable;
    @FXML private TableColumn<Client, String> nomColumn;
    @FXML private TableColumn<Client, String> contactColumn;
    @FXML private TableColumn<Client, String> emailColumn;
    @FXML private TableColumn<Client, String> telephoneColumn;
    @FXML private TableColumn<Client, String>  IDColumn;
    @FXML private TableColumn<Client,  Void> actionsColumn;
    @FXML private Button btnAjoutClient;
    @FXML private TextField searchField;

    private ObservableList<Client> clientList = FXCollections.observableArrayList();
    private ClientDao clientDao = new ClientDao();
    private HomeController homeController;

    @FXML
    public void initialize() {

        // Configure table columns
        IDColumn.setCellValueFactory(new PropertyValueFactory<>("id_client"));
        nomColumn.setCellValueFactory(new PropertyValueFactory<>("NomSoc"));
        contactColumn.setCellValueFactory(new PropertyValueFactory<>("adresse"));
        emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
        telephoneColumn.setCellValueFactory(new PropertyValueFactory<>("telephone"));


        // Configure buttons
        btnAjoutClient.setOnAction(e -> handleAjoutClient());

        // Set up row selection listener
        clientTable.getSelectionModel().selectedItemProperty().addListener(
                (obs, oldSelection, newSelection) -> {
                    if (newSelection != null) {
                        navigateToClientFactures(newSelection);
                    }
                });

        // Load initial data
        loadClients();

        // Set up search functionality
        searchField.textProperty().addListener((observable, oldValue, newValue) -> {
            filterClients(newValue);
        });
        searchField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue == null || newValue.trim().isEmpty()) {
                loadClients(); // recharge tous les clients si la recherche est vide
            } else {
                List<Client> resultats = clientDao.rechercherClients(newValue);
                clientList.setAll(resultats);
                clientTable.setItems(clientList);
            }
        });
        actionsColumn.setCellFactory(col -> new TableCell<Client, Void>() {
            private final Button editButton = new Button("✏️");
            private final Button deleteButton = new Button("🗑️");
            private final HBox pane = new HBox(editButton, deleteButton);

            {
                pane.setSpacing(10);

                // Action pour modifier
                editButton.setOnAction(event -> {
                    Client client = getTableView().getItems().get(getIndex());

                    try {
                        FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/Ajouter_client.fxml"));
                        Parent root = loader.load();

                        AjouterClientController controller = loader.getController();
                        controller.setClientController(ClientController.this);
                        controller.setClientToEdit(client);  // <--- Ici on passe le client à modifier

                        Stage stage = new Stage();
                        stage.setTitle("Modifier le client");
                        stage.setScene(new Scene(root));
                        stage.initModality(Modality.APPLICATION_MODAL);
                        stage.showAndWait();

                        // Refresh après fermeture
                        refreshClientList();

                    } catch (IOException e) {
                        showAlert("Erreur", "Impossible d'ouvrir la fenêtre de modification.");
                        e.printStackTrace();
                    }
                });

                // Action pour supprimer
                deleteButton.setOnAction(event -> {
                    Client client = getTableView().getItems().get(getIndex());

                    // Boîte de confirmation
                    Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
                    confirmation.setTitle("Confirmation de suppression");
                    confirmation.setHeaderText("Voulez-vous vraiment supprimer ce client ?");
                    confirmation.setContentText("Client : " + client.getNomSoc());

                    confirmation.showAndWait().ifPresent(response -> {
                        if (response == ButtonType.OK) {
                            try {
                                boolean success = supprimerClient(client.getId_client());
                                if (success) {
                                    getTableView().getItems().remove(client);
                                } else {
                                    showAlert("Échec", "La suppression du client a échoué.");
                                }
                            } catch (InvalidClientException e) {
                                showAlert("Erreur", "Erreur lors de la suppression : " + e.getMessage());
                            }
                        }
                    });
                });
            }


            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    setGraphic(pane);
                }
            }
        });
    }

    public void setHomeController(HomeController homeController) {
        this.homeController = homeController;
    }

    private void loadClients() {
        List<Client> clients = clientDao.getTous();
        clientList.setAll(clients);
        clientTable.setItems(clientList);
    }

    private void filterClients(String searchText) {
        if (searchText == null || searchText.isEmpty()) {
            clientTable.setItems(clientList);
            return;
        }

        ObservableList<Client> filteredList = FXCollections.observableArrayList();
        for (Client client : clientList) {
            if (client.getNomSoc().toLowerCase().contains(searchText.toLowerCase()) ||
                    client.getEmail().toLowerCase().contains(searchText.toLowerCase()) ||
                    client.getTelephone().toLowerCase().contains(searchText.toLowerCase())) {
                filteredList.add(client);
            }
        }
        clientTable.setItems(filteredList);
    }

    private void navigateToClientFactures(Client client) {
        if (homeController != null) {
            homeController.showFacturesForClient(client.getId_client());
        } else {
            showAlert("Erreur de Navigation", "Impossible d'accéder aux factures du client.");
        }
    }

    @FXML
    private void handleAjoutClient() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/Ajouter_client.fxml"));
            Parent root = loader.load();
            AjouterClientController addController = loader.getController();
            addController.setClientController(this);

             Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setTitle("Ajouter un client");
            stage.showAndWait();

            // Refresh client list after adding new client
            loadClients();
        } catch (IOException e) {
            showAlert("Erreur", "Impossible d'ouvrir le formulaire d'ajout de client.");
        }
    }
    public void refreshClientList() {
        loadClients();
    }
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}