package code;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public class AjouterCreanceController {

    @FXML private ComboBox<String> clientComboBox;
    @FXML private DatePicker dateCreanceFin;
    @FXML private TextField montantTotalField;

    @FXML
    public void initialize() {
        chargerListeClients();
    }

    private void chargerListeClients() {
        List<Client> clients = ClientDao.getTous();
        ObservableList<String> nomsClients = FXCollections.observableArrayList();

        for (Client c : clients) {
            nomsClients.add(c.getId_client() + " - " + c.getNomSoc());
        }

        clientComboBox.setItems(nomsClients);
    }

    @FXML
    private void enregistrerCreance() {
        String clientSelectionne = clientComboBox.getValue();
        LocalDate dateFin = dateCreanceFin.getValue();
        String montantTotalStr = montantTotalField.getText();

        if (clientSelectionne == null || dateFin == null || montantTotalStr.isEmpty()) {
            showAlert("Veuillez remplir tous les champs.");
            return;
        }

        try {
            double montantTotal = Double.parseDouble(montantTotalStr);
            String idClient = clientSelectionne.split(" - ")[0];

            // montantRestant = montantTotal (automatique)
            Creance c = new Creance(null, idClient, montantTotal, montantTotal, null, dateFin.toString(), "en_attente");

            boolean success = CreanceDao.ajouterCreance(c);

            if (success) {
                showAlert("✅ Créance ajoutée !");
                fermerFenetre();
            } else {
                showAlert("❌ Erreur lors de l'ajout.");
            }

        } catch (NumberFormatException e) {
            showAlert("Montant invalide.");
        } catch (SQLException e) {
            showAlert("Erreur SQL : " + e.getMessage());
        } catch (InvalidCreanceException e) {
            throw new RuntimeException(e);
        }
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void fermerFenetre() {
        Stage stage = (Stage) clientComboBox.getScene().getWindow();
        stage.close();
    }
}