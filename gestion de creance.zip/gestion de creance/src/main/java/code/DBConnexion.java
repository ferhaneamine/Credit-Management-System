package code;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnexion {

    private static final String URL = "jdbc:mysql://localhost:3306/gestion_creance";
    private static final String USER = "root";
    private static final String PASSWORD = "admin123";

    public static Connection connect() throws SQLException {
        try {
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException("Connection failed");
        }
    }
}