package code;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class PaiementDao {

    // Add a payment record (does NOT link to creance directly anymore)
    public static boolean ajouterPaiement(Paiement p) {
        String sql = "INSERT INTO paiement (id_paiement, montant_paye, date_paiement) VALUES (?, ?, ?)";

        try (Connection conn = DBConnexion.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            String id_paiement = genererIdPaiement();

            // Remove this line (use the date from Paiement object):
            // String date_paiement = new SimpleDateFormat("yyyy-MM-dd").format(new Date());

            stmt.setString(1, id_paiement);
            stmt.setDouble(2, p.getMontant());
            stmt.setString(3, p.getDate_paiement());
            stmt.executeUpdate();

            // Now link this payment to the creance using PayerDao
            PayerDao.ajouterLienPaiementCreance(p.getId_creance(), id_paiement, p.getMontant());

            // Update creance restant
            List<Creance> creances = CreanceDao.getCreances();
            Creance c = creances.stream()
                    .filter(cr -> cr.getId_Creance().equals(p.getId_creance()))
                    .findFirst().orElse(null);

            if (c != null) {
                double nouveauRestant = c.getMontantRestant() - p.getMontant();
                CreanceDao.modifierCreance(
                        c.getId_Creance(),
                        c.getMontantTotal(),
                        Math.max(0, nouveauRestant),
                        c.getDateFin()
                );
                CreanceDao.mettreAJourStatutsAutomatiquement();
            }

            return true;

        } catch (SQLException e) {
            System.out.println("Erreur ajout paiement : " + e.getMessage());
            return false;
        }
    }

    public static String genererIdPaiement() {
        String datePart = new SimpleDateFormat("yyyyMMdd").format(new Date());
        return "PMT-" + datePart + "-" + (int)(Math.random() * 900 + 100);
    }
    public static List<Paiement> getTousPaiements() {
        List<Paiement> liste = new ArrayList<>();
        String sql = "SELECT p.id_paiement, p.montant_paye as montant, p.date_paiement, "
                + "py.id_creance, c.NomSoc as clientName "  // Note: using py.id_creance from payer table
                + "FROM paiement p "
                + "JOIN payer py ON p.id_paiement = py.id_paiement "
                + "JOIN creance cr ON py.id_creance = cr.id_creance "
                + "JOIN client c ON cr.id_client = c.id_client";

        try (Connection conn = DBConnexion.connect();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Paiement p = new Paiement(
                        rs.getString("id_paiement"),
                        rs.getString("id_creance"),  // Now coming from payer table
                        rs.getDouble("montant"),
                        rs.getString("date_paiement"),
                        rs.getString("clientName")
                );
                liste.add(p);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching payments: " + e.getMessage());
        }
        return liste;
    }
    // Optional: fetch payments linked to a creance using a JOIN (using payer table)
    public static List<Paiement> getPaiementsByCreance(String id_creance) {
        List<Paiement> liste = new ArrayList<>();
        String sql = "SELECT p.id_paiement, p.montant_paye, p.date_paiement " +
                "FROM paiement p JOIN payer py ON p.id_paiement = py.id_paiement " +
                "WHERE py.id_creance = ?";

        try (Connection conn = DBConnexion.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, id_creance);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Paiement p = new Paiement(
                        rs.getString("id_paiement"),
                        id_creance,
                        rs.getDouble("montant_paye"),
                        rs.getString("date_paiement"),
                        rs.getString("NomSoc")
                );
                liste.add(p);
            }

        } catch (SQLException e) {
            System.out.println("Erreur récupération paiements par créance : " + e.getMessage());
        }

        return liste;
    }
    public static List<Paiement> rechercherPaiement(String keyword) {
        List<Paiement> liste = new ArrayList<>();
        String sql = "SELECT p.id_paiement, p.montant_paye as montant, p.date_paiement, "
                + "py.id_creance, c.NomSoc as clientName "  // Explicitly select id_creance from payer table
                + "FROM paiement p "
                + "JOIN payer py ON p.id_paiement = py.id_paiement "
                + "JOIN creance cr ON py.id_creance = cr.id_creance "
                + "JOIN client c ON cr.id_client = c.id_client "
                + "WHERE p.id_paiement LIKE ? "
                + "OR py.id_creance LIKE ? "
                + "OR c.NomSoc LIKE ? "
                + "OR p.date_paiement LIKE ?";

        try (Connection conn = DBConnexion.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            String searchPattern = "%" + keyword + "%";
            stmt.setString(1, searchPattern);  // id_paiement
            stmt.setString(2, searchPattern);  // id_creance
            stmt.setString(3, searchPattern);  // NomSoc (client)
            stmt.setString(4, searchPattern);  // date_paiement

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Paiement p = new Paiement(
                        rs.getString("id_paiement"),
                        rs.getString("id_creance"),  // Now properly aliased
                        rs.getDouble("montant"),
                        rs.getString("date_paiement"),
                        rs.getString("clientName")
                );
                liste.add(p);
            }
        } catch (SQLException e) {
            System.err.println("Erreur recherche paiements: " + e.getMessage());
            e.printStackTrace();
        }
        return liste;
    }
    public static List<String> getIdsCreances() {
        List<String> ids = new ArrayList<>();
        String sql = "SELECT id_creance FROM creance WHERE montantRestant > 0"; // Only unpaid debts
        try (Connection conn = DBConnexion.connect();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                ids.add(rs.getString("id_creance"));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching creances: " + e.getMessage());
        }
        return ids;
    }
    public static List<String> getClients() {
        List<String> clients = new ArrayList<>();
        String sql = "SELECT id_client, NomSoc FROM client";
        try (Connection conn = DBConnexion.connect();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                clients.add(rs.getString("id_client") + " - " + rs.getString("NomSoc"));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching clients: " + e.getMessage());
        }
        return clients;
    }
    public static List<String> getUnpaidCreancesForClient(String clientId) {
        List<String> creances = new ArrayList<>();
        String sql = "SELECT id_creance, montantRestant FROM creance WHERE id_client = ? AND montantRestant > 0";
        try (Connection conn = DBConnexion.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, clientId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                creances.add(rs.getString("id_creance") + " - " + rs.getDouble("montantRestant") + "€");
            }
        } catch (SQLException e) {
            System.err.println("Error fetching creances: " + e.getMessage());
        }
        return creances;
    }

    public static double getMontantTotal() {
        String sql = "SELECT SUM(montant_paye) AS total FROM paiement";
        try (Connection conn = DBConnexion.connect();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            if (rs.next()) {
                return rs.getDouble("total");
            }

        } catch (SQLException e) {
            System.err.println("Erreur récupération montant total : " + e.getMessage());
        }
        return 0;
    }
    public static double getMontantTotalParMois(String mois) {
        String sql = "SELECT SUM(montant_paye) AS total FROM paiement WHERE date_paiement LIKE ?";
        try (Connection conn = DBConnexion.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, mois + "%");
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getDouble("total");
            }

        } catch (SQLException e) {
            System.err.println("Erreur récupération montant par mois : " + e.getMessage());
        }
        return 0;
    }



}
