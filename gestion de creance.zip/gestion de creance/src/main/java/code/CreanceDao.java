package code;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;



public class CreanceDao {

    public static boolean ajouterCreance(Creance c) throws SQLException , InvalidCreanceException {
        try {
            validerCreance.validerDateFin(new SimpleDateFormat("yyyy-MM-dd").format(new Date()), c.getDateFin());
        } catch (InvalidCreanceException e) {
            System.out.println("Erreur validation date : " + e.getMessage());
            return false;
        }
        String sql = "INSERT INTO creance (id_creance, id_client, montantTotal, montantRestant, date_creation, dateFin, statut) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection co = DBConnexion.connect();
             PreparedStatement s = co.prepareStatement(sql)) {

            String id_creance = genererIdCreance();

            s.setString(1, id_creance);
            s.setString(2, c.getId_client());
            s.setDouble(3, c.getMontantTotal());
            s.setDouble(4, c.getMontantRestant());
            s.setString(5, new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
            s.setString(6, c.getDateFin());
            s.setString(7, (c.getMontantRestant() <= 0) ? "payee" : "en_attente");
            s.executeUpdate();
            return true;

        } catch (SQLException E) {
            System.out.println("Erreur d'ajout de créance : " + E.getMessage());
            return false;
        }
    }


    public static List<Creance> getCreancesByClient(String id_client) {
        mettreAJourStatutsAutomatiquement();
        List<Creance> liste = new ArrayList<>();
        String sql = "SELECT * FROM creance WHERE id_client = ?";
        try (Connection conn = DBConnexion.connect();
             PreparedStatement s = conn.prepareStatement(sql)) {

            s.setString(1, id_client);
            ResultSet r = s.executeQuery();
            while (r.next()) {
                Creance c = new Creance(
                        r.getString("id_creance"),
                        r.getString("id_client"),
                        r.getDouble("montantTotal"),
                        r.getDouble("montantRestant"),
                        r.getString("date_creation"),
                        r.getString("dateFin"),
                        r.getString("statut")
                );
                liste.add(c);
            }
        } catch (SQLException e) {
            System.out.println("Erreur récupération créances : " + e.getMessage());
        }
        return liste;
    }


    public static void modifierStatut(String idCreance, String statut) {
        String sql = "UPDATE creance SET statut = ? WHERE id_creance = ?";
        try (Connection conn = DBConnexion.connect();
             PreparedStatement s = conn.prepareStatement(sql)) {

            s.setString(1, statut);
            s.setString(2, idCreance);
            s.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Erreur lors de la mise à jour du statut : " + e.getMessage());
        }
    }

    public static void mettreAJourStatutsAutomatiquement() {
        String sql = "SELECT * FROM creance";
        try (Connection conn = DBConnexion.connect();
             Statement s = conn.createStatement();
             ResultSet r = s.executeQuery(sql)) {

            while (r.next()) {
                String id = r.getString("id_creance");
                double restant = r.getDouble("montantRestant");
                String dateFin = r.getString("dateFin");
                String nouveauStatut;

                Date today = new Date();
                Date dateLimite = new SimpleDateFormat("yyyy-MM-dd").parse(dateFin);

                if (restant <= 0) {
                    nouveauStatut = "payee";
                } else if (today.after(dateLimite)) {
                    nouveauStatut = "en_retard";
                } else {
                    nouveauStatut = "en_attente";
                }

                modifierStatut(id, nouveauStatut);
            }

        } catch (Exception e) {
            System.out.println("Erreur mise à jour automatique des statuts : " + e.getMessage());
        }
    }

    public static List<Creance> getCreances() {
        mettreAJourStatutsAutomatiquement();

        List<Creance> liste = new ArrayList<>();
        String sql = "SELECT * FROM creance";
        try (Connection conn = DBConnexion.connect();
             Statement s = conn.createStatement();
             ResultSet r = s.executeQuery(sql)) {

            while (r.next()) {
                Creance c = new Creance(
                        r.getString("id_creance"),
                        r.getString("id_client"),
                        r.getDouble("montantTotal"),
                        r.getDouble("montantRestant"),
                        r.getString("date_creation"),
                        r.getString("dateFin"),
                        r.getString("statut")
                );
                liste.add(c);
            }
        } catch (SQLException e) {
            System.out.println("Erreur récupération créances : " + e.getMessage());
        }
        return liste;
    }


    public static boolean modifierCreance(String id_creance, double montantTotal, double montantRestant, String dateFin) {
        String sql = "UPDATE creance SET montantTotal = ?, montantRestant = ?, dateFin = ? WHERE id_creance = ?";
        try (Connection conn = DBConnexion.connect();
             PreparedStatement s = conn.prepareStatement(sql)) {

            s.setDouble(1, montantTotal);
            s.setDouble(2, montantRestant);
            s.setString(3, dateFin);
            s.setString(4, id_creance);
            s.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.out.println("Erreur mise à jour de la créance : " + e.getMessage());
            return false;
        }
    }



    public static boolean supprimerCreance(String id_creance) {
        String sql = "DELETE FROM creance WHERE id_creance = ?";
        try (Connection conn = DBConnexion.connect();
             PreparedStatement s = conn.prepareStatement(sql)) {

            s.setString(1, id_creance);
            s.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.out.println("Erreur suppression créance : " + e.getMessage());
            return false;
        }
    }











    public static int avoirNombreCreance(String datePart) {
        String sql = "SELECT COUNT(*) FROM creance WHERE id_creance LIKE ?";
        try (Connection conn = DBConnexion.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, "CR-" + datePart + "-%");
            ResultSet r = stmt.executeQuery();

            if (r.next()) return r.getInt(1);

        } catch (SQLException e) {
            System.out.println("Erreur comptage créances : " + e.getMessage());
        }
        return 0;
    }









    public static String genererIdCreance() {
        String datePart = new SimpleDateFormat("yyyy/MM/dd").format(new Date());
        int count = avoirNombreCreance(datePart) + 1;
        String numero = String.format("%03d", count);
        return "CR-" + datePart + "-" + numero;
    }

    public static List<Creance> Filtrage(String statut) {
        List<Creance> liste = new ArrayList<>();
        String sql = "SELECT * FROM creance WHERE statut = ?";

        try (Connection conn = DBConnexion.connect();
             PreparedStatement s = conn.prepareStatement(sql)) {

            s.setString(1, statut);
            ResultSet r = s.executeQuery();

            while (r.next()) {
                Creance c = new Creance(
                        r.getString("id_creance"),
                        r.getString("id_client"),
                        r.getDouble("montantTotal"),
                        r.getDouble("montantRestant"),
                        r.getString("date_creation"),
                        r.getString("dateFin"),
                        r.getString("statut")
                );
                liste.add(c);
            }

        } catch (SQLException e) {
            System.out.println("❌ Erreur récupération par statut : " + e.getMessage());
        }

        return liste;
    }

    public static List<Creance> rechercher(String critere) {
        List<Creance> liste = new ArrayList<>();
        String sql = "SELECT * FROM creance WHERE id_creance LIKE ? OR date_creation LIKE ?";

        try (Connection conn = DBConnexion.connect();
             PreparedStatement s = conn.prepareStatement(sql)) {

            String motCle = "%" + critere + "%";
            s.setString(1, motCle);
            s.setString(2, motCle);
            ResultSet r = s.executeQuery();

            while (r.next()) {
                Creance c = new Creance(
                        r.getString("id_creance"),
                        r.getString("id_client"),
                        r.getDouble("montantTotal"),
                        r.getDouble("montantRestant"),
                        r.getString("date_creation"),
                        r.getString("dateFin"),
                        r.getString("statut")
                );
                liste.add(c);
            }

        } catch (SQLException e) {
            System.out.println("❌ Erreur recherche par ID ou date : " + e.getMessage());
        }

        return liste;
    }
    public static double getTotalMontantCreances() {
        String sql = "SELECT SUM(montantTotal) FROM creance";
        try (Connection conn = DBConnexion.connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getDouble(1);
        } catch (SQLException e) {
            System.out.println("Erreur somme créances : " + e.getMessage());
        }
        return 0;
    }
    public static double getTotalMontantCreancesParMois(String mois) {
        String sql = "SELECT SUM(montantTotal) FROM creance WHERE date_creation LIKE ?";
        try (Connection conn = DBConnexion.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, mois + "%");
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) return rs.getDouble(1);
        } catch (SQLException e) {
            System.out.println("Erreur total par mois : " + e.getMessage());
        }
        return 0;
    }
    public static int getNombreParStatut(String statut) {
        String sql = "SELECT COUNT(*) FROM creance WHERE statut = ?";
        try (Connection conn = DBConnexion.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, statut);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.out.println("Erreur nombre par statut : " + e.getMessage());
        }
        return 0;
    }
    public static double getTotalMontantParStatut(String statut) {
        String sql = "SELECT SUM(montantRestant) FROM creance WHERE statut = ?";
        try (Connection conn = DBConnexion.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, statut);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) return rs.getDouble(1);
        } catch (SQLException e) {
            System.out.println("Erreur total montant par statut : " + e.getMessage());
        }
        return 0;
    }
    public static List<Creance> getCreancesRecentes() {
        List<Creance> liste = new ArrayList<>();
        String sql = "SELECT * FROM creance ORDER BY date_creation DESC LIMIT 5";
        try (Connection conn = DBConnexion.connect();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Creance c = new Creance(
                        rs.getString("id_creance"),
                        rs.getString("id_client"),
                        rs.getDouble("montantTotal"),
                        rs.getDouble("montantRestant"),
                        rs.getString("date_creation"),
                        rs.getString("dateFin"),
                        rs.getString("statut")
                );
                liste.add(c);
            }
        } catch (SQLException e) {
            System.out.println("Erreur créances récentes : " + e.getMessage());
        }
        return liste;
    }




}