package code;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class AjouterPaiementController {

    @FXML private ComboBox<String> creanceComboBox;
    @FXML private ComboBox<String> clientComboBox;
    @FXML private DatePicker datePaiement;
    @FXML private TextField montantField;
    @FXML private TextField dateField;
    private String selectedClientId;

    private Runnable onPaymentAdded;
    public void setOnPaymentAdded(Runnable callback) {
        this.onPaymentAdded = callback;
    }


    @FXML
    public void initialize() {
        // Charger les créances disponibles
        creanceComboBox.setItems(javafx.collections.FXCollections.observableArrayList(
                PaiementDao.getIdsCreances()
        ));
        clientComboBox.setItems(FXCollections.observableArrayList(
                PaiementDao.getClients() ));
        dateField.setText(LocalDate.now().format(DateTimeFormatter.ISO_DATE));

        // Update creance dropdown when client is selected
        clientComboBox.setOnAction(e -> {
            String selectedClient = clientComboBox.getValue();
            if (selectedClient != null) {
                String clientId = selectedClient.split(" - ")[0];
                creanceComboBox.setItems(FXCollections.observableArrayList(
                        PaiementDao.getUnpaidCreancesForClient(clientId)
                ));
                creanceComboBox.setDisable(false);
            }
            selectedClientId = selectedClient.split(" - ")[0];

        });

    }
    @FXML
    private void enregistrerPaiement() {
        String clientSelection = clientComboBox.getValue();
        String creanceSelection = creanceComboBox.getValue();
        String montantText = montantField.getText();

        // Validate inputs first
        if (clientSelection == null || creanceSelection == null || montantText.isEmpty()) {
            showAlert("Veuillez remplir tous les champs !");
            return;
        }

        try {
            // Extract client ID and name
            String[] clientParts = clientSelection.split(" - ");
            String clientId = clientParts[0];
            String clientName = clientParts[1]; // This is the NomSoc from your query

            // Extract creance ID
            String creanceId = creanceSelection.split(" - ")[0];
            double montant = Double.parseDouble(montantText);

            // Create payment with all required fields
            Paiement paiement = new Paiement(
                    null, // will be generated
                    creanceId,
                    montant,
                    LocalDate.now().format(DateTimeFormatter.ISO_DATE), // auto date
                    clientName // from the client selection
            );

            // Now attempt to add the payment
            if (PaiementDao.ajouterPaiement(paiement)) {
                if (onPaymentAdded != null) {
                    onPaymentAdded.run(); // Notify the parent controller
                }
                closeWindow();
            } else {
                showAlert("Erreur lors de l'enregistrement.");
            }
        } catch (NumberFormatException e) {
            showAlert("Montant invalide !");
        } catch (ArrayIndexOutOfBoundsException e) {
            showAlert("Format de sélection invalide !");
        }
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR, message, ButtonType.OK);
        alert.showAndWait();
    }

    private void closeWindow() {
        Stage stage = (Stage) creanceComboBox.getScene().getWindow();
        stage.close();
    }
    public String getSelectedClientId() {
        return selectedClientId;
    }
}

