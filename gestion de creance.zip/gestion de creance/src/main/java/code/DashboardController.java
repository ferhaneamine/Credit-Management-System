package code;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class DashboardController {

    @FXML private Label labelTotalCreances;
    @FXML private Label pourcentageCreances;
    @FXML private Label labelMontantPaye;
    @FXML private Label pourcentagePaye;
    @FXML private Label labelNbFacturesAttente;
    @FXML private Label labelMontantAttente;
    @FXML private Label labelNbFacturesRetard;
    @FXML private Label labelMontantRetard;
    @FXML private Label pourcentageRetard;

    @FXML private TableView<Creance> facturesRecents;
    @FXML private TableColumn<Creance, String> colReference;
    @FXML private TableColumn<Creance, String> colFournisseur;
    @FXML private TableColumn<Creance, String> colDateEcheance;
    @FXML private TableColumn<Creance, Double> colMontant;
    @FXML private TableColumn<Creance, String> colStatut;

    @FXML
    public void initialize() {
        String moisActuel = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM"));
        String moisDernier = LocalDate.now().minusMonths(1).format(DateTimeFormatter.ofPattern("yyyy-MM"));

        // Total créances
        double totalActuel = CreanceDao.getTotalMontantCreances();
        double totalAncien = CreanceDao.getTotalMontantCreancesParMois(moisDernier);
        double pourcentCreance = (totalAncien == 0) ? 0 : ((totalActuel - totalAncien) / totalAncien) * 100;

        labelTotalCreances.setText(totalActuel + " DA");
        pourcentageCreances.setText(String.format("%.2f %%", pourcentCreance));

        // Montant payé
        double payeActuel = PaiementDao.getMontantTotal();
        double payeDernier = PaiementDao.getMontantTotalParMois(moisDernier);
        double pourcentPaye = (payeDernier == 0) ? 0 : ((payeActuel - payeDernier) / payeDernier) * 100;

        labelMontantPaye.setText(payeActuel + " DA");
        pourcentagePaye.setText(String.format("%.2f %%", pourcentPaye));

        // En attente
        int nbAttente = CreanceDao.getNombreParStatut("en_attente");
        double montantAttente = CreanceDao.getTotalMontantParStatut("en_attente");
        labelNbFacturesAttente.setText(nbAttente + " créances");
        labelMontantAttente.setText(montantAttente + " DA");

        // En retard
        int nbRetard = CreanceDao.getNombreParStatut("en_retard");
        double montantRetard = CreanceDao.getTotalMontantParStatut("en_retard");
        labelNbFacturesRetard.setText(nbRetard + " créances");
        labelMontantRetard.setText(montantRetard + " DA");
        pourcentageRetard.setText("—"); // Si vous avez un calcul pour le pourcentage de retard, vous pouvez l'ajouter ici

        // Créances récentes
        colReference.setCellValueFactory(new PropertyValueFactory<>("id_Creance"));
        colFournisseur.setCellValueFactory(new PropertyValueFactory<>("id_client"));
        colDateEcheance.setCellValueFactory(new PropertyValueFactory<>("dateFin"));
        colMontant.setCellValueFactory(new PropertyValueFactory<>("montantTotal"));
        colStatut.setCellValueFactory(new PropertyValueFactory<>("statut"));

        // Formater la date de fin avant l'affichage (si nécessaire)
        colDateEcheance.setCellFactory(col -> new TableCell<Creance, String>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (!empty && item != null) {
                    LocalDate date = LocalDate.parse(item); // Assurez-vous que le format est correct
                    setText(date.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
                } else {
                    setText(null);
                }
            }
        });

        // Récupération des créances récentes et affichage dans le tableau
        List<Creance> recentes = CreanceDao.getCreancesRecentes(); // méthode à ajouter si pas encore faite
        ObservableList<Creance> data = FXCollections.observableArrayList(recentes);
        facturesRecents.setItems(data);
    }
}
