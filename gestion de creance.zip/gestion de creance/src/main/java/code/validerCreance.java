package code;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class validerCreance {

    public static void validerDateFin(String dateCreation, String dateFin) throws InvalidCreanceException {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date d1 = sdf.parse(dateCreation);
            Date d2 = sdf.parse(dateFin);

            if (d2.before(d1)) {
                throw new InvalidCreanceException(" La date de fin ne peut pas être antérieure à la date de création.");
            }

        } catch (ParseException e) {
            throw new InvalidCreanceException(" Format de date invalide.");
        }
    }
}
