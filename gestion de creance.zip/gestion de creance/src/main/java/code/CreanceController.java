package code;

import code.Creance;
import code.CreanceDao;
import code.ClientDao;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;

public class CreanceController {

    @FXML private TableView<Creance> factureTable;
    @FXML private TableColumn<Creance, String> refCol;
    @FXML private TableColumn<Creance, String> fournisseurCol;
    @FXML private TableColumn<Creance, String> dateEmissionCol;
    @FXML private TableColumn<Creance, Double> montantTotalCol;
    @FXML private TableColumn<Creance, Double> montantRestantCol;
    @FXML private TableColumn<Creance, String> statutCol;
    @FXML private TableColumn<Creance, Void> actionsCol;

    @FXML private TextField searchField;
    @FXML private Button btnNouvelleFacture, btnToutes, btnPayees, btnEnAttente, btnEnRetard;

    private ObservableList<Creance> creanceList;

    @FXML
    public void initialize() {
        loadTableData(CreanceDao.getCreances());
        setupListeners();
    }

    private void loadTableData(java.util.List<Creance> data) {
        creanceList = FXCollections.observableArrayList(data);
        factureTable.setItems(creanceList);

        refCol.setCellValueFactory(cell -> new javafx.beans.property.SimpleStringProperty(cell.getValue().getId_Creance()));
        fournisseurCol.setCellValueFactory(cell -> new javafx.beans.property.SimpleStringProperty(cell.getValue().getId_client()));
        dateEmissionCol.setCellValueFactory(cell -> new javafx.beans.property.SimpleStringProperty(cell.getValue().getdate_creance()));
        montantTotalCol.setCellValueFactory(cell -> new javafx.beans.property.SimpleObjectProperty<>(cell.getValue().getMontantTotal()));
        montantRestantCol.setCellValueFactory(cell -> new javafx.beans.property.SimpleObjectProperty<>(cell.getValue().getMontantRestant()));
        statutCol.setCellValueFactory(cell -> new javafx.beans.property.SimpleStringProperty(cell.getValue().getStatut()));

        // Optional: Ajouter icônes d’action ici (modifier, supprimer)
        // setupActionButtons(); (à implémenter si tu veux gérer ça maintenant)
    }

    private void setupListeners() {
        searchField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal.isEmpty()) {
                loadTableData(CreanceDao.getCreances());
            } else {
                loadTableData(CreanceDao.rechercher(newVal));
            }
        });

        btnToutes.setOnAction(e -> loadTableData(CreanceDao.getCreances()));
        btnPayees.setOnAction(e -> loadTableData(CreanceDao.Filtrage("payee")));
        btnEnAttente.setOnAction(e -> loadTableData(CreanceDao.Filtrage("en_attente")));
        btnEnRetard.setOnAction(e -> loadTableData(CreanceDao.Filtrage("en_retard")));
    }
    public void setClientFilter(String idClient) {
        loadTableData(CreanceDao.getCreancesByClient(idClient));
    }
    @FXML
    private void handleAjouter() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/AjouterCreance.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setTitle("Nouvelle créance");
            stage.setScene(new Scene(root));
            stage.setResizable(false);
            stage.showAndWait();

            // Recharger les données après fermeture du popup
            loadTableData(CreanceDao.getCreances());

        } catch (IOException e) {
            System.out.println("❌ Erreur ouverture popup ajout créance : " + e.getMessage());
            e.printStackTrace();
        }
    }
}