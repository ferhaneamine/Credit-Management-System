package code;

import javafx.scene.control.Alert;
import java.util.List;

public class AlertManager {

    public static void verifierAlertesClient(String idClient) {
        List<Creance> creances = CreanceDao.getCreancesByClient(idClient);

        boolean aCreanceRetard = false;
        boolean aCreancePayee = false;

        for (Creance c : creances) {
            if (c.getStatut().equalsIgnoreCase("en_retard")) {
                aCreanceRetard = true;
            }
            if (c.getMontantRestant() == 0) {
                aCreancePayee = true;
            }
        }

        if (aCreanceRetard) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Alerte Client");
            alert.setHeaderText("Créances en retard !");
            alert.setContentText("Ce client a des créances en retard. ⚠");
            alert.showAndWait();
        }

        if (aCreancePayee) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Paiement terminé");
            alert.setHeaderText("Créance réglée !");
            alert.setContentText("Une créance du client vient d’être totalement payée ✅");
            alert.showAndWait();
        }
    }
}
