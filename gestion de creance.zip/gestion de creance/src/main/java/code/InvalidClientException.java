package code;

public class InvalidClientException extends Exception {
    public InvalidClientException (String msg) {
        super(msg);
    }

}