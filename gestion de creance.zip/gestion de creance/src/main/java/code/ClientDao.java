package code;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;






public class ClientDao {

    public static boolean ajouterClient(Client client) throws InvalidClientException {

        validerClient.validerNomSoc(client.getNomSoc());
        validerClient.validerEmail(client.getEmail());
        validerClient.validerNumeroTel(client.getTelephone());
        validerClient.validerIdClient(client.getId_client());


        String sql = " INSERT INTO client (id_client, NomSoc , adresse , telephone, email) VALUES (?,?,?,?,?) ";
        try (Connection c = DBConnexion.connect();
             PreparedStatement s = c.prepareStatement(sql)) {


            s.setString(1, client.getId_client());
            s.setString(2, client.getNomSoc());
            s.setString(3, client.getAdresse());
            s.setString(4, client.getTelephone());
            s.setString(5, client.getEmail());

            int rowsAffected = s.executeUpdate();
            return rowsAffected > 0;



        }catch (SQLException e) {
            // Handle duplicate ID case
            if (e.getMessage().contains("duplicate") || e.getErrorCode() == 1062) {
                throw new InvalidClientException("Cet ID client existe déjà");
            }
            System.err.println("Erreur d'ajout: " + e.getMessage());
            return false;
        }



    }
    public static List<Client> rechercherClients(String motCle) {
        List<Client> resultats = new ArrayList<>();
        String sql = "SELECT * FROM client WHERE id_client LIKE ? OR NomSoc LIKE ?";

        try (Connection conn = DBConnexion.connect();
             PreparedStatement s = conn.prepareStatement(sql)) {

            String keyword = "%" + motCle + "%";
            s.setString(1, keyword);
            s.setString(2, keyword);

            ResultSet rs = s.executeQuery();
            while (rs.next()) {
                Client c = new Client(
                        rs.getString("id_client"),
                        rs.getString("NomSoc"),
                        rs.getString("adresse"),
                        rs.getString("telephone"),
                        rs.getString("email")
                );
                resultats.add(c);
            }
        } catch (SQLException e) {
            System.out.println("Erreur recherche client : " + e.getMessage());
        }
        return resultats;
    }
    public static boolean modifierClient(Client client) throws InvalidClientException {

        validerClient.validerNomSoc(client.getNomSoc());
        validerClient.validerEmail(client.getEmail());
        validerClient.validerNumeroTel(client.getTelephone());

        String sql = "UPDATE client SET NomSoc = ?, adresse = ?, telephone = ?, email = ? WHERE id_client = ?";

        try (Connection c = DBConnexion.connect();
             PreparedStatement s = c.prepareStatement(sql)) {

            s.setString(1, client.getNomSoc());
            s.setString(2, client.getAdresse());
            s.setString(3, client.getTelephone());
            s.setString(4, client.getEmail());
            s.setString(5, client.getId_client()); // 🔴 L'ID est utilisé uniquement dans le WHERE (en dernier)

            int rows = s.executeUpdate();
            System.out.println("Lignes modifiées : " + rows);
            return rows > 0;

        } catch (SQLException e) {
            System.out.println("Erreur modification : " + e.getMessage());
            return false;
        }
    }


    public static boolean supprimerClient (String id_client ) throws InvalidClientException {

        String sql = "DELETE FROM client WHERE id_client = ?";
        try (Connection c = DBConnexion.connect();
             PreparedStatement s = c.prepareStatement(sql)){
            s.setString(1, id_client);
            s.executeUpdate();
            return true ;

        }catch (SQLException E) {
            System.out.println("Erreur de suppression: "+ E.getMessage());
            return false;
        }
    }
    public static List<Client> getTous() {
        List<Client> liste = new ArrayList<>();
        String sql = "SELECT * FROM client";
        try (Connection conn = DBConnexion.connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Client c = new Client(
                        rs.getString("id_client"),
                        rs.getString("NomSoc"),
                        rs.getString("adresse"),
                        rs.getString("telephone"),
                        rs.getString("email")
                );
                liste.add(c);
            }
        } catch (SQLException e) {
            System.out.println(" Erreur affichage : " + e.getMessage());
        }
        return liste;
    }
    public static List<Creance> getCreances() {
        List<Creance> liste = new ArrayList<>();
        String sql = "SELECT * FROM creance";  // Fixed the SQL query (removed WHERE clause)
        try (Connection conn = DBConnexion.connect();
             Statement s = conn.createStatement();
             ResultSet r = s.executeQuery(sql)) {
            while (r.next()) {
                Creance c = new Creance(
                        r.getString("id_creance"),
                        r.getString("id_client"),
                        r.getDouble("montantTotal"),
                        r.getDouble("montantRestant"),
                        r.getString("date_creation"),
                        r.getString("dateFin"),
                        r.getString("statut")
                );
                liste.add(c);
            }
        } catch (SQLException e) {
            System.out.println("Erreur récupération créances : " + e.getMessage());
        }
        return liste;
    }





}