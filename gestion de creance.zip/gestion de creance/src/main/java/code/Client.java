package code;

public class Client {
    private String id_client;
    private String NomSoc;
    private String adresse;
    private String telephone;
    private String email;

    public Client(String id_client, String NomSoc, String adresse, String telephone, String email) {
        this.id_client = id_client;
        this.NomSoc = NomSoc;
        this.adresse = adresse;
        this.telephone = telephone;
        this.email = email;
    }

    public  String getId_client() {
        return id_client;
    }

    public void setId_client(String id_client) {
        this.id_client = id_client;
    }

    public String getNomSoc() {
        return NomSoc;
    }

    public void setNomSoc(String NomSoc) {
        this.NomSoc = NomSoc;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}