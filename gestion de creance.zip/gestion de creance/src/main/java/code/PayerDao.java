package code;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PayerDao {

    // Adds a link between creance and paiement in Payer table
    public static boolean ajouterLienPaiementCreance(String id_creance, String id_paiement, double montant_affecte) {
        String sql = "INSERT INTO payer (id_creance, id_paiement, montant_affecte) VALUES (?, ?, ?)";

        try (Connection conn = DBConnexion.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, id_creance);
            stmt.setString(2, id_paiement);
            stmt.setDouble(3, montant_affecte);

            stmt.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.out.println("Erreur ajout lien paiement-créance : " + e.getMessage());
            return false;
        }
    }
}
