package code;

import java.sql.Date;



public class Creance {
    private String id_Creance;
    private String id_client;
    private double montantTotal;
    private double montantRestant;
    private String date_creation;
    private String dateFin;
    private String statut;


    public Creance(String id_Creance, String id_client, double montantTotal, double montantRestant, String date_creation, String dateFin, String statut) {
        this.id_Creance = id_Creance;
        this.id_client = id_client;
        this.montantTotal = montantTotal;
        this.montantRestant = montantRestant;
        this.date_creation = date_creation;
        this.dateFin = dateFin;
        this.statut = statut;

    }

    // Getters & Setters
    public String getId_Creance() {
        return id_Creance;
    }

    public void setId_Creance(String id_Creance) {
        this.id_Creance = id_Creance;
    }

    public String getId_client() {
        return id_client;
    }

    public void setId_client(String id_client) {
        this.id_client = id_client;
    }

    public double getMontantTotal() {
        return montantTotal;
    }

    public void setMontantTotal(double montantTotal) {
        this.montantTotal = montantTotal;
    }

    public double getMontantRestant() {
        return montantRestant;
    }

    public void setMontantRestant(double montantRestant) {
        this.montantRestant = montantRestant;
    }

    public String getdate_creance() {
        return date_creation;
    }

    public void setDate_creation(String date_creation) {
        this.date_creation = date_creation;
    }

    public String getDateFin() {
        return dateFin;
    }

    public void setDateFin(String dateFin) {
        this.dateFin = dateFin;
    }

    public String getStatut() {
        return statut;
    }

    public void setStatut(String statut) {
        this.statut = statut;
    }



}
