package code;

import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.util.Callback;

import java.io.IOException;

public class PaiementController {
    @FXML private TableView<Paiement> paimentTable;  // Fixed typo in variable name
    @FXML private TableColumn<Paiement, String>referenceCol;  // Fixed French spelling
    @FXML private TableColumn<Paiement, String> creanceCol;
    @FXML private TableColumn<Paiement, String> clientCol;  // Singular for consistency
    @FXML private TableColumn<Paiement, String>dateCol;
    @FXML private TableColumn<Paiement, Double> montantCol;

    @FXML private TextField searchField;
    @FXML private Button btnAjoutPaiment;  // Fixed typo

    private ObservableList<Paiement> paiementList;

    @FXML
    public void initialize() {
        configureTableColumns();
        refreshPayments();
        setupListeners();
    }

    private void configureTableColumns() {
        // Clear existing items to prevent duplicates
        paimentTable.getItems().clear();

        // Configure column value factories
        referenceCol.setCellValueFactory(cell ->
                new SimpleStringProperty(cell.getValue().getId_paiement()));

        creanceCol.setCellValueFactory(cell ->
                new SimpleStringProperty(cell.getValue().getId_creance()));

        clientCol.setCellValueFactory(cell ->
                new SimpleStringProperty(cell.getValue().getClientName()));

        dateCol.setCellValueFactory(cell ->
                new SimpleStringProperty(cell.getValue().getDate_paiement()));

        montantCol.setCellValueFactory(cell ->
                new SimpleObjectProperty<>(cell.getValue().getMontant()));

        // Format montant column to show currency
        montantCol.setCellFactory(tc -> new TableCell<>() {
            @Override
            protected void updateItem(Double montant, boolean empty) {
                super.updateItem(montant, empty);
                setText(empty ? null : String.format("%,.2f DA", montant));
            }
        });
    }

    private void setupListeners() {
        // Search functionality
        searchField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal == null || newVal.trim().isEmpty()) {
                refreshPayments();
            } else {
                paiementList.setAll(PaiementDao.rechercherPaiement(newVal.trim()));
            }
        });

        // Add payment button
        btnAjoutPaiment.setOnAction(e -> handleAjouterPaiments());
    }

    @FXML
    private void handleAjouterPaiments() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/AjouterPaiement.fxml"));
            Parent root = loader.load();

            AjouterPaiementController controller = loader.getController();
            controller.setOnPaymentAdded(this::refreshPayments);

            Stage stage = new Stage();
            stage.setTitle("Nouveau Paiement");
            stage.setScene(new Scene(root));
            stage.setResizable(false);
            stage.showAndWait();
            String clientId = controller.getSelectedClientId();
            if (clientId != null && !clientId.isEmpty()) {
                AlertManager.verifierAlertesClient(clientId);
            }

        } catch (IOException e) {
            showErrorAlert("Erreur", "Impossible d'ouvrir la fenêtre d'ajout", e);
        }

    }

    private void refreshPayments() {
        paiementList = FXCollections.observableArrayList(PaiementDao.getTousPaiements());
        paimentTable.setItems(paiementList);
    }

    private void showErrorAlert(String title, String header, Exception e) {
        System.err.println(header + ": " + e.getMessage());
        e.printStackTrace();

        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(e.getMessage());
        alert.showAndWait();
    }
}