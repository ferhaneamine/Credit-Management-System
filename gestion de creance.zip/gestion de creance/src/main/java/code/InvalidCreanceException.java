package code;

public class InvalidCreanceException extends Exception {
    public InvalidCreanceException (String msg) {
        super(msg);
    }

}