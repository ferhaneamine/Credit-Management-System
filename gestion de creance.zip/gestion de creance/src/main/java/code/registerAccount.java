package code;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import java.sql.*;

public class registerAccount {

    private static final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

    public static boolean register(String username, String password) {
        if (usernameExists(username)) {
            return false;
        }

        String hashedPassword = encoder.encode(password);
        String sql = "INSERT INTO utilisateur (username, mot_de_passe) VALUES (?, ?)";

        try (Connection c = DBConnexion.connect();
             PreparedStatement s = c.prepareStatement(sql)) {
            s.setString(1, username);
            s.setString(2, hashedPassword);
            return s.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static int login(String username, String password) {
        String sql = "SELECT id_utilisateur, mot_de_passe FROM utilisateur WHERE username = ?";
        try (Connection c = DBConnexion.connect();
             PreparedStatement s = c.prepareStatement(sql)) {
            s.setString(1, username);
            ResultSet rs = s.executeQuery();

            if (rs.next()) {
                String storedHash = rs.getString("mot_de_passe");
                if (encoder.matches(password, storedHash)) {
                    return rs.getInt("id_utilisateur");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    public static boolean usernameExists(String username) {
        String sql = "SELECT 1 FROM utilisateur WHERE username = ?";
        try (Connection c = DBConnexion.connect();
             PreparedStatement s = c.prepareStatement(sql)) {
            s.setString(1, username);
            return s.executeQuery().next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
