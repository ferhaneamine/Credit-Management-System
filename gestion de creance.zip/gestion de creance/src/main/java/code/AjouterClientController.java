package code;



import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;
import javafx.stage.Stage;

public class AjouterClientController {
    @FXML private TextField idField;
    @FXML private TextField nomField;
    @FXML private TextField adresseField;
    @FXML private TextField emailField;
    @FXML private TextField telephoneField;
    private String ancienIdClient = null;
    private ClientDao clientDao = new ClientDao();
    private ClientController clientController;

    @FXML
    private void enregistrerClient() {
        try {
            if (nomField.getText().trim().isEmpty()) {
                showAlert("Erreur", "Le nom de la société est obligatoire");
                return;
            }

            Client client = new Client(
                    ancienIdClient,  // 🟢 on utilise toujours l’ancien ID, pas le champ désactivé
                    nomField.getText().trim(),
                    adresseField.getText().trim(),
                    telephoneField.getText().trim(),
                    emailField.getText().trim()
            );

            boolean success;
            if (clientToEdit == null) {
                client.setId_client(idField.getText().trim()); // Pour l'ajout, on utilise ce que l’utilisateur a saisi
                success = clientDao.ajouterClient(client);
            } else {
                success = clientDao.modifierClient(client);  // utilise l’ID correct
            }

            if (success) {
                if (clientController != null) {
                    clientController.refreshClientList();
                }
                closeWindow();
            } else {
                showAlert("Erreur", "Échec de l'opération");
            }
        } catch (InvalidClientException e) {
            showAlert("Erreur de validation", e.getMessage());
        } catch (Exception e) {
            showAlert("Erreur", "Une erreur est survenue: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void setClientController(ClientController controller) {
        this.clientController = controller;
    }

    private void closeWindow() {
        Stage stage = (Stage) idField.getScene().getWindow();
        stage.close();
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    private Client clientToEdit = null;
    public void setClientToEdit(Client client) {
        this.clientToEdit = client;
        this.ancienIdClient = client.getId_client();  // on garde l’ID ici même si champ désactivé

        idField.setText(client.getId_client());
        nomField.setText(client.getNomSoc());
        adresseField.setText(client.getAdresse());
        telephoneField.setText(client.getTelephone());
        emailField.setText(client.getEmail());

        idField.setDisable(true); // Ne pas autoriser la modification
    }
}