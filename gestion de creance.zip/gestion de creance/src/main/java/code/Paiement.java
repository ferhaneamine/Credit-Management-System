package code;

public class Paiement {
    private String id_paiement;
    private String id_creance;
    private double montant;
    private String date_paiement;
    private String clientName;

    public Paiement(String id_paiement, String id_creance, double montant, String date_paiement , String clientName) {
        this.id_paiement = id_paiement;
        this.id_creance = id_creance;
        this.montant = montant;
        this.date_paiement = date_paiement;
        this.clientName = clientName;
    }

    public String getId_paiement() {
        return id_paiement;
    }

    public void setId_paiement(String id_paiement) {
        this.id_paiement = id_paiement;
    }

    public String getId_creance() {
        return id_creance;
    }

    public void setId_creance(String id_creance) {
        this.id_creance = id_creance;
    }

    public double getMontant() {
        return montant;
    }

    public void setMontant(double montant) {
        this.montant = montant;
    }

    public String getDate_paiement() {
        return date_paiement;
    }

    public void setDate_paiement(String date_paiement) {
        this.date_paiement = date_paiement;
    }
    public String getClientName() {
        return clientName;
    }
    public void setClientName(String clientName) {
        this.clientName = clientName;
    }
}